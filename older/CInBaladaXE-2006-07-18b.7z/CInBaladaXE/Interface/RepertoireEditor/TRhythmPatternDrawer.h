
#ifndef __TRhythmPatternDrawer__
#define __TRhythmPatternDrawer__

#include <Classes.hpp>
#include <ExtCtrls.hpp>
//__fastcall TCDirectoryOutline::TCDirectoryOutline(TComponent* Owner)

class TRhythmPatternDrawer : public TPaintBox {
private:

public:
    __fastcall TRhythmPatternDrawer(TComponent* Owner);

};

#endif