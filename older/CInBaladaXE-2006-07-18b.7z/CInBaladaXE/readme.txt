Todos os padr�es quatern�rios preparados para o CInBalada
(inclusive com instrumentos que tem apenas um ou dois padr�es).
15/07/2006